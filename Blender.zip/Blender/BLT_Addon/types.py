from bpy.utils import register_class, unregister_class


# 自定义注册类
class BLT_Registerable():
  @classmethod
  def blt_register(cls):
    register_class(cls)

  @classmethod
  def blt_unregister(cls):
    unregister_class(cls)
