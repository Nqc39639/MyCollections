import os, shutil

import bpy
from bpy.props import StringProperty
from bpy.types import Operator

from ..modules.blt_addon import BLT_Server
from ..modules.settings import BLT_Settings
from ..types import BLT_Registerable
from ..utils import BLT_Info


class BLT_TransGlobal(Operator, BLT_Registerable):
  bl_idname = "blt.translation_global"
  bl_label = "全局翻译本地插件"
  bl_description = "全局翻译本地插件"
  bl_options = {'INTERNAL'}

  def execute(self, context):
    if BLT_Info.is_enabled_global_translation():
      BLT_Info.remove_global_translation()
    else:
      try:
        BLT_Server.getGlobaltran()
      except:
        self.report({'ERROR'}, "网络有问题...可以请尝试换个网络，如手机USB连接或手机WIFI分享！")
        return {'FINISHED'}
      source = BLT_Info.blender_addon_locale_path + '/languages'
      target = BLT_Info.blender_global_locale_path + "/languages"
      shutil.copyfile(source, target)
    bpy.ops.blt.dialog('INVOKE_DEFAULT')
    return {'FINISHED'}
