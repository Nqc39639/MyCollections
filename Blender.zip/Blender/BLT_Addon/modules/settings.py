from os.path import isfile

from .blt_addon import BLT_Server
from ..utils import BLT_Info
from ..types import BLT_Registerable

class BLT_Settings(BLT_Registerable):

    @classmethod
    def blt_register(cls):
        # 插件注册初始化代码
        BLT_Info.mkdir_if_not_exists(BLT_Info.blt_path)

    @classmethod
    def blt_unregister(cls):
      pass

    @staticmethod
    def load_global_translation_changelog():
        preferences = BLT_Info.get_preferences()
        preferences.global_translation_changelog = BLT_Server.get_global_changelog()
