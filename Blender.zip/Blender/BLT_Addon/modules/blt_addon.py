import os, sys, time, zipfile, shutil, ftplib

from urllib import request

from ..utils import BLT_Info

class BLT_Server:

  @staticmethod
  def copy_dir(old, target):

    if not (os.path.isdir(old) and not os.path.isdir(target)):
      return

    for a in os.walk(old):
      for d in a[1]:
        dir_path = os.path.join(a[0].replace(old, target), d)
        if not os.path.isdir(dir_path):
          os.makedirs(dir_path)

      for f in a[2]:
        dep_path = os.path.join(a[0], f)
        arr_path = os.path.join(a[0].replace(old, target), f)
        shutil.copy(dep_path, arr_path)

  @staticmethod
  def getGlobaltran():
    homepathstr = BLT_Info.blender_global_path

    AllExtractINfo = homepathstr + "/" + "BLT_translation_Dicts/datafiles.zip"
    if os.path.isfile(AllExtractINfo):
      os.remove(AllExtractINfo)
    if os.path.exists(BLT_Info.blt_datafile_path):
      shutil.rmtree(BLT_Info.blt_datafile_path)

    webpath="http://raw.pjcgart.com/blt_Translation/mo/datafiles.zip"
    request.urlretrieve(webpath,AllExtractINfo)

    zip_file = zipfile.ZipFile(AllExtractINfo)
    zip_list = zip_file.namelist()

    for f in zip_list:
      zip_file.extract(f, BLT_Info.blt_path)
    zip_file.close()

    if os.path.exists(BLT_Info.blt_locale_path):
      if not os.path.exists(BLT_Info.blender_global_datafile_path):
        os.mkdir(BLT_Info.blender_global_datafile_path)
      BLT_Server.copy_dir(BLT_Info.blt_locale_path,
                          BLT_Info.blender_global_locale_path)

  @staticmethod
  def get_global_changelog():
    changelog = ""
    try:
      resp = request.urlopen(
          'https://raw.pjcgart.com/blt_Translation/mo/Mo_UpdateVersion.txt'
      )
      changelog = resp.read().decode()
    except:
      pass
    return changelog
