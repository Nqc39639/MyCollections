from .operators.dialog import BLT_QuitDialog
from .operators.translation import BLT_TransGlobal
from .preferences import BLT_Preferences
from .modules.settings import BLT_Settings

# 排序的类
# 确保其中的类均继承自 BLT_Registerable
sorted_classes = [
    # 退出窗口
    BLT_QuitDialog,
    # 操作
    BLT_TransGlobal,
    # 偏好设置
    BLT_Preferences,
    # 用户设置
    BLT_Settings
]


def register():
  for cls in sorted_classes:
    cls.blt_register()


def unregister():
  for cls in sorted_classes[::-1]:
    cls.blt_unregister()
