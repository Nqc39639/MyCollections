from bpy.types import AddonPreferences
from bpy.props import (BoolProperty, EnumProperty, StringProperty,
                       CollectionProperty)

from .utils import BLT_Info
from .types import BLT_Registerable
from .modules.settings import BLT_Settings


class BLT_Preferences(AddonPreferences, BLT_Registerable):
  bl_idname = BLT_Info.addon_name

  @classmethod
  def blt_register(cls):
    super().blt_register()
    # 初始化偏好设置数据
    BLT_Info.get_preferences().search_translation = ""

  tabs: EnumProperty(items=[("GTRANSLATION", "全局翻译[GT]", "全局翻译"),
                            ("LINKS", "相关链接[LK]", "相关链接")],
                     name="选项卡",
                     description="设置选项卡")

  global_translation_changelog: StringProperty(name="全局翻译日志", default="")

  def draw_global_translation(self, contxt):
    layout = self.layout
    enabled = BLT_Info.is_enabled_global_translation()
    layout.operator("blt.translation_global",
                    text="已启用全局翻译" if enabled else "未启用全局翻译",
                    icon='FILE_REFRESH',
                    depress=enabled)
    message = layout.row()
    message.alignment = 'CENTER'
    message.label(text="启用或禁用全局翻译后, 重启 Blender 后生效!!!")
    if self.global_translation_changelog == "":
      BLT_Settings.load_global_translation_changelog()
    layout = layout.box()
    changelog = self.global_translation_changelog.split("\n")
    for line in changelog:
      while line:
        layout.label(text=line[:40])
        line = line[40:]

  def draw_links(self, contxt):
    layout = self.layout
    flow = layout.column_flow(columns=2)

    column1 = flow.column().box()
    url_title = column1.row()
    url_title.alignment = 'CENTER'
    url_title.label(text="文档与反馈")
    urls = column1.row()
    urls.operator("wm.url_open", text="帮助文档").url = BLT_Info.url_document
    urls.operator("wm.url_open",
                  text="问答平台").url = BLT_Info.url_question_and_answer

    column2 = flow.column().box()
    about_title = column2.row()
    about_title.alignment = 'CENTER'
    about_title.label(text="关于插件")
    about_msg = column2.row()
    about_msg.label(text="此插件为免费插件, 禁止用于任何商业用途", icon='ERROR')

  def draw(self, context):
    layout = self.layout
    tabs = layout.row()
    tabs.prop(self, "tabs", expand=True)
    layout.separator()
    if self.tabs == 'GTRANSLATION':
      self.draw_global_translation(context)
    elif self.tabs == 'LINKS':
      self.draw_links(context)
    layout.separator()
