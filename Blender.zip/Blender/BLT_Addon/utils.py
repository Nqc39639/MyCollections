import sys

from os import getenv, mkdir
from os.path import dirname, realpath, exists
from shutil import rmtree

import bpy
from bpy.app import binary_path, version


class BLT_Info:

  addon_name = __package__
  addon_root_path = dirname(realpath(__file__))
  blender_addon_locale_path = addon_root_path + "/locale"

  blender_base_version = "%d.%d" % (version[0], version[1])

  blender_global_path = ""
  if sys.platform == 'win32':
    blender_global_path = getenv("APPDATA") + "/Blender Foundation/Blender"
  elif sys.platform == 'darwin':
    blender_global_path = getenv(
        "HOME") + "/Library/Application Support/Blender"
  else:
    raise Exception("不支持的系统平台: " + sys.platform)

  blt_path = blender_global_path + "/BLT_translation_Dicts"
  blt_datafile_path = blt_path + "/datafiles"
  blt_locale_path = blt_datafile_path + "/locale"

  blender_global_version_path = "%s/%s" % (blender_global_path,
                                           blender_base_version)
  blender_global_datafile_path = blender_global_version_path + "/datafiles"
  blender_global_locale_path = blender_global_datafile_path + "/locale"

  url_document = "https://pjcgart.com/2019/04/10/blt/"
  url_question_and_answer = "https://blt.qa.pjcgart.com/"

  @staticmethod
  def get_preferences():
    return bpy.context.preferences.addons[BLT_Info.addon_name].preferences

  @staticmethod
  def mkdir_if_not_exists(path):
    if not exists(path):
      mkdir(path)

  @staticmethod
  def is_enabled_global_translation():
    return exists(BLT_Info.blender_global_locale_path)

  @staticmethod
  def remove_global_translation():
    rmtree(BLT_Info.blender_global_locale_path)
