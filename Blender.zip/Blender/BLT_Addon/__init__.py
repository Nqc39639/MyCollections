'''
Copyright (C) 2020 PJ PENG
pjwaixingren@me.com
Created by pjpeng
'''

bl_info = {
    "name": "BLT",
    "description": "This addon use to BLT Software",
    "author": "Keshi, pjwaixingren",
    "version": (0, 1, 8),
    "blender": (2, 80, 0),
    "location": "Menu BlT",
    "warning": "This addon is still in development.",
    "wiki_url": "https://www.pjcgart.com",
    "tracker_url": "https://blt.qa.pjcgart.com",
    "category": "Object"
}

import bpy
import bpy.utils.previews
from bpy.props import StringProperty, BoolProperty, EnumProperty

import ctypes
import multiprocessing
import os
import sys
import shutil
import socket
import subprocess
import sys
from threading import Thread

from .modules.websocket import create_connection
from .modules.websocket_server import WebsocketServer

class bltrunss(bpy.types.Operator):
  bl_idname = "blt.bltrunss"
  bl_label = "BLT_CONNECT"
  bl_description = "BLT_CONNECT"

  def execute(self, context):
    print("info"+bpy.context.scene.blt_message_objectname)
    self.report({'INFO'}, '"' + bpy.context.scene.blt_message_objectname + '" :已经导入Blender(Blender Import Finished)!!!')
    return {'FINISHED'}

systemusepath = os.environ['APPDATA']
homepathold = systemusepath + "\Blender Foundation\Blender"
homepathstr = homepathold.replace("\"", "//")
BLTFolderpath = homepathstr + "/BLT_translation_Dicts/"
Exepath=sys.argv[0]

class bltcheck(bpy.types.Operator):
  bl_idname = "blt.check"
  bl_label = "ConnectBLTSoftWare"
  bl_description = "ConnectBLT"   
  def execute(self,context):
    tasklist_result = os.popen("tasklist")
    tasklist_stream = tasklist_result._stream
    tasklist = tasklist_stream.buffer.read().decode(encoding="utf-8", errors="ignore")
    if tasklist.find("BLT_")!=-1:
      print("getBLTEXE")
    else:
      print("NOTgetBLTEXE")
      bpy.ops.blt.bltrun()
    return {'FINISHED'}

class bltrun(bpy.types.Operator):
  bl_idname = "blt.bltrun"
  bl_label = "StartRunBLT"
  bl_description = "StartRunBLT"
  
  def getinfoandblend(self):
    getinfofile = BLTFolderpath + "/info/BLT_Version.info"
    blt_exe_Path=""
    if os.path.exists(getinfofile) == False:
      self.report(
          {'ERROR'},
          "你还没有安装和使用过BLT！！-Please Download and Install BLT at Frist!!!")
      return
    if os.path.exists(getinfofile) == True:
      data = open(getinfofile.replace("\"", "//"), 'r')
      datainfo = data.read()
      data.close()
    blt_exe_Path = datainfo.split("\nVersion:")[0].split('ExePath:')[1]
    return blt_exe_Path

  def execute(self, context):
    blt_exe_Path = self.getinfoandblend()
    if blt_exe_Path!="":
      get_exe_name = blt_exe_Path.split("\\")[-1]
      self.report({'INFO'}, "BLT已经被开启，请等待...-BLT Runing Now..Please Wating...")
      subprocess.call("TASKKILL /F /IM " + "\"" + get_exe_name + "\"")
      subprocess.Popen(blt_exe_Path) 
    return {'FINISHED'}

preview_collections = {}

class bltmain(bpy.types.Header):
  bl_space_type = 'TOPBAR'
  bl_idname = 'BLT_HT_HEADER'

  # @staticmethod
  def blt_draw(self, context):
    if sys.platform != 'win32':
      return

    if context.region.alignment != 'RIGHT':
      layout = self.layout
      row = layout.row(align=True)
      layout = self.layout
      
      layout.operator("blt.check", text="", icon_value=icons["bltlogo"].icon_id)

  def draw(self, context):
    bltmain.blt_draw(self, context)
    icons = preview_collections["main"]
    
#==================================================        
def importsendmsg():
    ws = create_connection("ws://127.0.0.1:33333")
    info = '"' + bpy.context.scene.blt_message_objectname + '" :已经导入Blender(Blender Import Finished)!!!'
    ws.send(info)
    ws.close()
    print(info)
    

def new_client(client, server):
    server.send_message_to_all("GetServer")

def message_received(client, server, message):
  message=message.encode('raw_unicode_escape').decode("utf-8")
  print(message)
  if message.find("FilePath:") != -1:
    bpy.context.scene.blt_message=message
    for window in bpy.context.window_manager.windows:
      for area in window.screen.areas: 
        if area.type == 'VIEW_3D':
          space_data = area.spaces.active
          message = bpy.context.scene.blt_message
          GetBlenderFile = message.split(":Filetype:")[0].split("FilePath:")[1]
          GetFileType = message.split(":Filetype:")[1]

          Getobjectname = GetBlenderFile.split("/")[-1].split(".")[0]

          blendfile = Getobjectname + ".blend"

          bpy.context.scene.blt_message_objectname = Getobjectname

          if (GetFileType == "Object"):
            directoryname = GetBlenderFile + "/" + GetFileType + "/"
            with bpy.data.libraries.load(GetBlenderFile) as (data_from, data_to):
              data_to.objects=data_from.objects
              data_to.collections = data_from.collections
            a = 0
            for obj in data_to.objects:
              if obj.name==Getobjectname:
                a = 1
            b=0
            for collet in data_to.collections:
              if collet.name==Getobjectname:
                b=1
            collection=Getobjectname
            if a == 1 and b == 0:
              directoryname = GetBlenderFile + "/" + GetFileType + "/"
              for obj in data_to.objects:
                if obj.name == collection:
                  bpy.context.scene.collection.objects.link(obj)
            if a == 0 and b == 1:
              directoryname = GetBlenderFile + "/" + "Collection/"
              for new_coll in data_to.collections:
                if new_coll.name == collection:
                  bpy.context.scene.collection.children.link(new_coll)
            if a == 1 and b == 1:
              directoryname = GetBlenderFile + "/" + "Collection/"
              for new_coll in data_to.collections:
                if new_coll.name == collection:
                  bpy.context.scene.collection.children.link(new_coll)
            if a == 0 and b == 0:
              directoryname = GetBlenderFile + "/" + "Collection/"
              for new_coll in data_to.collections:
                  bpy.context.scene.collection.children.link(new_coll)
            a=0
            b=0

          if (GetFileType == "Material"):
            directoryname = GetBlenderFile + "/" + GetFileType + "/"
            with bpy.data.libraries.load(GetBlenderFile) as (data_from, data_to):
              data_to.materials=data_from.materials
            
            for material in data_to.materials:
                  if material.name==Getobjectname:
                      print("import now!!!")
          
          if (GetFileType == "HDRI"):
            hdrworld=bpy.data.worlds['World']
            hdrworld.use_nodes = True
            for i in bpy.data.worlds['World'].node_tree.nodes:
                bpy.data.worlds['World'].node_tree.nodes.remove(i)
            hdroutput=bpy.data.worlds['World'].node_tree.nodes.new("ShaderNodeOutputWorld")
            hdroutput.location=(680,200)
            hdrbg = bpy.data.worlds['World'].node_tree.nodes.new("ShaderNodeBackground")
            hdrbg.location=(400,200)
            hdrnode = bpy.data.worlds['World'].node_tree.nodes.new("ShaderNodeTexEnvironment")
            hdrnode.image = bpy.data.images.load(GetBlenderFile)
            hdrlinks=bpy.data.worlds['World'].node_tree.links
            hdrnodes=bpy.data.worlds['World'].node_tree.nodes
            hdrnode.location=(0,150)

            uv_node=hdrnodes.new(type="ShaderNodeTexCoord")
            uv_node.location=(-300,150)

            map_node=hdrnodes.new(type="ShaderNodeMapping")
            map_node.vector_type="TEXTURE"
            map_node.inputs['Rotation'].default_value =(0,0,3.141593)
            uv_node.location=(-150,150)

            links=hdrlinks.new(hdrnode.outputs[0],hdrbg.inputs[0])
            links_map=hdrlinks.new(map_node.outputs[0],hdrnode.inputs[0])
            links_uv=hdrlinks.new(uv_node.outputs[0],map_node.inputs[0])
            links_woldout=hdrlinks.new(hdrbg.outputs[0],hdroutput.inputs[0])
          #=========================================  
          for space in area.spaces:
                if space.type == 'VIEW_3D':
                    space.shading.type = 'RENDERED'      
          
    # importsendmsg()
    t1 = Thread(None,importsendmsg)
    t1.setDaemon(True)
    t1.start()

  
  if message.find("Blender(Blender Import Finished)") != -1:
    print("Send Message!!!")
    try:
        server.send_message_to_all(message)
    except :
        pass
    

def startServer(input,*args):
  try:
    server = WebsocketServer(33333, host='127.0.0.1')
    server.set_fn_new_client(new_client)
    server.set_fn_message_received(message_received)
    server.run_forever()
  except:
    pass
#==================================================   
from . import auto_load


def register():
  #=================================
  try:
    if not os.path.exists(BLTFolderpath+"/info"):
        os.makedirs(BLTFolderpath+"/info")
    getblinfofile=BLTFolderpath+"/info/Blender.info"
    data = open(getblinfofile.replace("\"", "//"), 'w')
    datainfo = data.write(str(Exepath).replace("\"", "//"))
    data.close()
  except:
    pass
  #=================================

  bpy.types.Scene.blt_message = bpy.props.StringProperty(name="")
  bpy.types.Scene.blt_message_objectname = bpy.props.StringProperty(name="")
  bpy.types.Scene.blt_message_directoryname = bpy.props.StringProperty(name="")
  bpy.utils.register_class(bltrun)
  bpy.utils.register_class(bltrunss)
  bpy.utils.register_class(bltcheck)
  bpy.types.TOPBAR_HT_upper_bar.append(bltmain.blt_draw)
  
 

  global icons
  icons = bpy.utils.previews.new()
  icons_dir = os.path.join(os.path.dirname(__file__), "icons")
  icons.load("bltlogo", os.path.join(icons_dir, "gray.png"), 'IMAGE')
  preview_collections['main']=icons
  auto_load.register()


def unregister():
  for icons in preview_collections.values():
      bpy.utils.previews.remove(icons)
  preview_collections.clear()
  del bpy.types.Scene.blt_message
  del bpy.types.Scene.blt_message_objectname
  del bpy.types.Scene.blt_message_directoryname
  bpy.types.TOPBAR_HT_upper_bar.remove(bltmain.blt_draw)
  bpy.utils.unregister_class(bltrunss)
  bpy.utils.unregister_class(bltrun)
  bpy.utils.unregister_class(bltcheck)

  auto_load.unregister()

t = Thread(None,startServer,None,('MyStringHere',1))
t.setDaemon(True)
t.start()

