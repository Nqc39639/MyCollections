class Point:
	def __init__(self, pos, size, color):
		self.pos = pos
		self.size = size
		self.color = color


class Polyline:
	def __init__(self, points, thickness, color):
		self.points = points
		self.thickness = thickness
		self.color = color


class Drawer2d:

	def __init__(self):
		self._points = []
		self._polylines = []

	def point(self, pos, size, color):
		self._points.append(Point(pos, size, color))

	def polyline(self, points, thickness, color):
		self._polylines.append(Polyline(points, thickness, color))

	def render(self):
		# create scene
		# create object + mesh + material
		# render to image file
		# load image
		# clean
		pass
