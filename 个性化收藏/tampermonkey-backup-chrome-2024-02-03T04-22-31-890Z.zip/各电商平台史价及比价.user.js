// ==UserScript==
// @name        各电商平台史价及比价
// @namespace   zkq8
// @description  【无领券】【无广告】脚本从购物党官网下载而来，经过去多余，且碍眼的展示条目，只保留了比价+历史价格曲线。非常清爽的一个脚本。
// @run-at      document-end
// @author    max
// @version     0.1
// @grant 	   none
// @require     http://youhuicity.com/bijialib.js
// @include     http://*.jd.com/*
// @include     https://*.jd.com/*
// @include     http://*.jd.hk/*
// @include     https://*.jd.hk/*
// @include     http://*.taobao.com/*
// @include     https://*.taobao.com/*
// @include     http://*.tmall.com/*
// @include     https://*.tmall.com/*
// @include     https://*.tmall.hk/*
// @license MIT
// @copyright 2020, max (https://youhou8.com/users/max)
// ==/UserScript==

(function() {
	var s = document.createElement('script');
	s.setAttribute('src', '@require');
	document.body.appendChild(s);
})();